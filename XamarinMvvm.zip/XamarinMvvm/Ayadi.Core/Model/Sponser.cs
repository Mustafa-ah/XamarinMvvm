﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ayadi.Core.Model
{
    public class Sponser : BaseModel
    {
        public string FilePath { get; set; }
        public int SponsorImageId { get; set; }

    }
}

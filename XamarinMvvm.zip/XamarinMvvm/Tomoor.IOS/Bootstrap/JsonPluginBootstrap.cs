using MvvmCross.Platform.Plugins;

namespace Tomoor.IOS.Bootstrap
{
    public class JsonPluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.Json.PluginLoader>
    {
    }
}
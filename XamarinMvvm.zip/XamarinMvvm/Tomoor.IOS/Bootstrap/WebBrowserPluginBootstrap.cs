using MvvmCross.Platform.Plugins;

namespace Tomoor.IOS.Bootstrap
{
    public class WebBrowserPluginBootstrap
        : MvxLoaderPluginBootstrapAction<MvvmCross.Plugins.WebBrowser.PluginLoader, MvvmCross.Plugins.WebBrowser.iOS.Plugin>
    {
    }
}
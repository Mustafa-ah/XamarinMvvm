﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;
using Ayadi.Core.Contracts.Services;

namespace Tomoor.IOS.Services
{
    class HomeActivityUiService : IHomeActivityUiService
    {
        public void SetAccountFoucs()
        {
            throw new NotImplementedException();
        }

        public void SetCatsFoucs()
        {
            throw new NotImplementedException();
        }

        public void SetHomeFoucs()
        {
            throw new NotImplementedException();
        }

        public void SetSettingFoucs()
        {
            throw new NotImplementedException();
        }

        public void SetStoreFoucs()
        {
            throw new NotImplementedException();
        }
    }
}